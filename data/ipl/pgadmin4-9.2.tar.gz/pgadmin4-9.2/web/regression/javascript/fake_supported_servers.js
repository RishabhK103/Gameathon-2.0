//////////////////////////////////////////////////////////////////////////
//
// pgAdmin 4 - PostgreSQL Tools
//
// Copyright (C) 2013 - 2025, The pgAdmin Development Team
// This software is released under the PostgreSQL Licence
//
//////////////////////////////////////////////////////////////////////////

module.exports = [
  {label: 'EDB Advanced Server', value: 'ppas'},
  {label: 'PostgreSQL', value: 'pg'},
  {label: 'Unknown', value: ''},
];
