import React from 'react';
export default function UplotReact() {
  return <></>;
}
