//////////////////////////////////////////////////////////////////////////
//
// pgAdmin 4 - PostgreSQL Tools
//
// Copyright (C) 2013 - 2025, The pgAdmin Development Team
// This software is released under the PostgreSQL Licence
//
//////////////////////////////////////////////////////////////////////////

define(function () {
  return {
    'INTERNAL': 'internal',
    'LDAP': 'ldap',
    'KERBEROS': 'kerberos'
  };
});

