import gunicorn
gunicorn.SERVER_SOFTWARE = 'Python'
