# pgAdmin Linux Build Scripts

This directory contains package build scripts and assets that are common to 
various Linux distributions. 

You should not use them directly, but the functionality provided can be used to
simplify your own build scripts (typically by sourcing *build-functions.sh*).
